<?php 
// This cache file is automatically generated at:2019-08-07 14:12:41
declare (strict_types = 1);
return array (
);