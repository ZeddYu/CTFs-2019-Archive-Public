#!/bin/bash 

service apache2 start

tail -f /dev/null