<?php
//000000000000s:11:"static_home";
?>