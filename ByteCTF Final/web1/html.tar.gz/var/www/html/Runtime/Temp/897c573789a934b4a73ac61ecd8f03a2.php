<?php
//000000000000a:5:{s:8:"avatar32";s:38:"Public/images/default_avatar_32_32.jpg";s:8:"avatar64";s:38:"Public/images/default_avatar_64_64.jpg";s:9:"avatar128";s:40:"Public/images/default_avatar_128_128.jpg";s:9:"avatar256";s:40:"Public/images/default_avatar_256_256.jpg";s:9:"avatar512";s:40:"Public/images/default_avatar_512_512.jpg";}
?>