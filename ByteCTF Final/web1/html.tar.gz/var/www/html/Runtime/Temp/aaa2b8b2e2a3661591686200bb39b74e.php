<?php
//000000000000a:3:{s:9:"space_url";s:46:"/index.php?s=/ucenter/index/index/uid/104.html";s:10:"space_link";s:106:"<a ucard="104" target="_blank" href="/index.php?s=/ucenter/index/index/uid/104.html">checker1571404682</a>";s:13:"space_mob_url";s:41:"/index.php?s=/mob/user/index/uid/104.html";}
?>