<?php
//000000000000a:4:{i:0;s:3:"all";i:1;s:9:"concerned";i:2;s:3:"hot";i:3;s:3:"fav";}
?>