<?php
//000000000000a:12:{s:4:"name";s:15:"below_checkrank";s:4:"type";i:1;s:5:"width";s:5:"280px";s:6:"height";s:5:"100px";s:5:"title";s:18:"签到下方广告";s:6:"status";i:1;s:5:"theme";s:3:"all";s:6:"margin";s:0:"";s:7:"padding";s:0:"";s:4:"data";s:2:"[]";s:4:"path";s:18:"Weibo/Index/search";s:2:"id";i:10001;}
?>