<?php
//000000000000a:3:{s:5:"title";s:31:"{$MODULE_ALIAS}-{$website_name}";s:8:"keywords";s:15:"{$MODULE_ALIAS}";s:11:"description";s:21:"{$MODULE_ALIAS}首页";}
?>