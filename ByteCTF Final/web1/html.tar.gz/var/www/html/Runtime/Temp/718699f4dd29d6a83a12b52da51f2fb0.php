<?php
//000000000000a:3:{i:0;a:2:{s:5:"title";s:12:"合作单位";s:3:"url";s:32:"Addons/adminList?name=SuperLinks";}i:1;a:2:{s:5:"title";s:12:"举报后台";s:3:"url";s:28:"Addons/adminList?name=Report";}i:2;a:2:{s:5:"title";s:12:"推荐关注";s:3:"url";s:31:"Addons/adminList?name=Recommend";}}
?>