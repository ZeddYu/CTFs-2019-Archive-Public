<?php
//000000000000a:11:{s:2:"id";s:2:"15";s:4:"date";s:10:"1570723200";s:8:"day1_num";s:1:"0";s:8:"day2_num";s:1:"0";s:8:"day3_num";s:1:"0";s:8:"day4_num";s:1:"0";s:8:"day5_num";s:1:"0";s:8:"day6_num";s:1:"0";s:8:"day7_num";i:0;s:8:"day8_num";s:1:"0";s:7:"reg_num";s:1:"0";}
?>