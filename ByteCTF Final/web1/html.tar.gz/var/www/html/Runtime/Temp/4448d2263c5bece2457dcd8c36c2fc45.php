<?php
//000000000000s:226:"<a href="http://www.ourstu.com/joinus.html" target="_blank"><p><i class="icon icon-user"></i>加入我们</p></a><p><i class="icon icon-phone-sign"></i>400-0573-080</p><p><i class="icon icon-envelope-alt"></i>co@ourstu.com</p>";
?>