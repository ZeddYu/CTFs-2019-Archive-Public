<?php
//000000000000s:117:"<p>Copyright ©2014-2017 <a href="http://www.ourstu.com" target="_blank">嘉兴想天信息科技有限公司</a></p>";
?>