<?php
//000000000000a:9:{s:4:"type";N;s:4:"meta";s:0:"";s:4:"bind";s:1:"0";s:5:"QqKEY";s:0:"";s:8:"QqSecret";s:0:"";s:7:"SinaKEY";s:0:"";s:10:"SinaSecret";s:0:"";s:9:"WeixinKEY";s:0:"";s:12:"WeixinSecret";s:0:"";}
?>