<?php
//000000000000a:12:{s:2:"id";s:1:"4";s:4:"name";s:15:"below_self_info";s:5:"title";s:18:"个人资料下方";s:4:"path";s:17:"Weibo/Index/index";s:4:"type";s:1:"1";s:6:"status";s:1:"1";s:4:"data";s:0:"";s:5:"width";s:5:"280px";s:6:"height";s:5:"100px";s:6:"margin";s:10:"0 0 10px 0";s:7:"padding";s:0:"";s:5:"theme";s:3:"all";}
?>