<?php
//000000000000a:3:{s:9:"space_url";s:46:"/index.php?s=/ucenter/index/index/uid/102.html";s:10:"space_link";s:106:"<a ucard="102" target="_blank" href="/index.php?s=/ucenter/index/index/uid/102.html">checker1571404401</a>";s:13:"space_mob_url";s:41:"/index.php?s=/mob/user/index/uid/102.html";}
?>