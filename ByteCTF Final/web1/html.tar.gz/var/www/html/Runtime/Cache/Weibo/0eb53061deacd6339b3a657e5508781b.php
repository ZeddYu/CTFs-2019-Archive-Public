<?php if (!defined('THINK_PATH')) exit();?><div data-position="one-weibo" style="max-width: 680px;" data-role="id_weibo" id="weibo_2" class="">
    <div class="all-wrap">
                    <div class="new-user-first-weibo"></div>        <div class="weibo-content">
            <div class="content-head">
                <div class="avat-box pull-left">
                    <a href="/index.php?s=/ucenter/index/index/uid/102.html" ucard="102">
                        <span style="position: relative;display: inline-block;">
                                    <img src="Public/images/default_avatar_128_128.jpg" class="avatar-img">
                                  </span>                    </a>
                    <div class="show-follow pull-right">
                        <div class="follow-btn" style="display: none;">
                            
                        </div>
                    </div>
                </div>
                <div class="op-box pull-right">
                    <div class="op-tb op-top">
                        <a ucard="102" href="/index.php?s=/ucenter/index/index/uid/102.html" class="user_name">
                            checker1571404401
                        </a>
                        <small class="font_grey">Lv1 实习</small>                        &nbsp;
                        <!--隐藏操作列表-->
                                            </div>
                    <div class="op-tb op-bottom">
                        <a data-hover="查看详情" class="wb-time" href="/index.php?s=/weibo/index/weibodetail/id/2.html">
                            刚刚
                        </a>
                    </div>
                </div>
            </div>
            <div class="content-info row">
                <p class='word-wrap'>gOhlzHXPixrNx5eMavoPLsQWVqE6AXDEulTBOvJWkGUKuJfopYRCqcke4Rfdj9Uy</p>                 <div class="form-where">
                    <div class="where w-left">
                        <span>来自 网站端 </span>
                        <span></span>
                    </div>
                    <div class="where w-right  bottom-operate" data-weibo-id="2">
                                                <div class="col-xs-3 operate-color">
    <a title="喜欢" data-role="support-weibo" table="weibo" row="2" uid="102" jump="weibo/index/weibodetail">
        <i class="weibo_like icon-heart-empty"></i>
        <span id="support_Weibo_weibo_2_pos"><span id="support_Weibo_weibo_2">0</span> </span>
    </a>
</div>
<div class=" col-xs-3 operate-color" data-role="weibo_comment_btn"  data-weibo-id="2">
   <i class="os-icon-bubbles"></i> 0</div>
<div class="col-xs-3 operate-color">
        <a title="转发"  data-role="send_repost"  href="/index.php?s=/weibo/index/sendrepost/sourceId/2/weiboId/2.html"><i class="os-icon-share-alt"></i> 0</a>
</div>
<div class="share_button col-xs-3  operate-color" style="padding: 0px;position: relative;">
    <span class="cpointer weibo_share_btn_2" data-weibo-id="2">
        <a data-role="weibo_share_btn" class="share-btn" title="分享"><i class="os-icon-share"></i><!--<span class="share_count" title="累计分享0次" style="margin-left: 5px;">0</span>--></a>
    </span>
    <div class="share_block" data-url="http://172.29.13.12/index.php?s=/weibo/index/weibodetail/id/2.html" data-text="gOhlzHXPixrNx5eMavoPLsQWVqE6AXDEulTBOvJWkGUKuJfopYRCqcke4Rfdj9Uy" data-dec="分享动态" style="display: none;">
        <div class="bdsharebuttonbox" data-tag="share_feedlist">
            <a class="bds_qzone" data-cmd="qzone" title="分享到QQ空间" data-id="2">QQ空间</a>
            <a class="bds_tsina" data-cmd="tsina" title="分享到新浪动态" data-id="2">新浪动态</a>
            <a class="bds_tqq" data-cmd="tqq" title="分享到腾讯动态" data-id="2">腾讯动态</a>
            <a class="bds_weixin" data-cmd="weixin" title="分享到微信" data-id="2">微信</a>
            <a class="bds_sqq" data-cmd="sqq" title="分享到QQ好友" data-id="2">QQ好友</a>
            <!--<a class="bds_count" data-cmd="count" style="display: none;"></a>-->
        </div>
        <div style="position: relative;">
            <div class="tip"></div>
            <div class="tip-xs"></div>
        </div>
    </div>
    <script src="/Application/Weibo/Static/js/bdshare.js"></script>
</div>
                    </div>
                </div>
            </div>
        </div>

        </div>
        <div class="weibo-bottom weibo-comment-list row" style="display: block;margin:0;"  data-weibo-id="2">
            <div class="top-triangle-border"></div>
            <div class="top-triangle-content"></div>
            <div class="bottom-top">
                <div class="pull-left left-like-list text-more text-color">
                    <a title="喜欢" data-role="support-weibo" class="text-color" table="weibo" row="2" uid="102" jump="weibo/index/weibodetail">
                        <i class="weibo_like icon-heart-empty"></i>
                        <span class="support-text">点赞</span>                    </a>
                    <span id="supporter_Weibo_weibo_2">
                                            </span>
                </div>
                <a class="pull-right right-say-button" data-role="show-comment-input" data-id="2"><i class="iconfont icon-you"></i>说一句</a>
            </div>
            <div class="comment-list-block">
                <div class=" weibo-comment-block">
                        <div class="weibo-comment-container">
                            <div class="weibo_post_box">
    <p class="comment-area">
        <input type="hidden"  name="reply_id" value="0"/>

        <input type="text" placeholder="评论（Ctrl+Enter）" id="text_2" rows="2" data-weibo-id="2"
               class="comment-input  weibo-comment-content comment_text_inputor">

        <a style="margin-right: 10px" href="javascript:" class="" onclick="insertFace($(this))"><i style="color: #999;" class="os-icon-emoticon-smile"></i> </a>
        <a  data-role="do_comment" id="btn_2" data-type="weibo-list" data-weibo-id="2">
            <i class="os-icon-paper-plane"></i> </a>
    </p>

    <div id="emot_content" class="emot_content" style="position: absolute;    right: 425px;
    top: 45px;"></div>
    <!--评论列表-->
</div>
<div id="show_comment_2" class="weibo_comment_list" data-comment-count="0" style="border-bottom: none;">
    <div class="pager" style="display: none!important;margin: 11px 20px 0;">
    </div>
</div>


<script>
    $(function () {
        var weiboid = '2';
        $('#text_' + weiboid + '').keypress(function (e) {
            if (e.ctrlKey && e.which == 13 || e.which == 10) {
                $('#btn_' + weiboid + '').click();
            }
        });
    });
</script>                        </div>
                    </div>            </div>
        </div>
    </div>
</if>
<style>
    .suofang {MARGIN: auto;WIDTH: 200px;}
    .suofang img{MAX-WIDTH: 100%!important;HEIGHT: auto!important;width:expression(this.width > 300 ? "300px" :this.width)!important;}
</style>