<?php if (!defined('THINK_PATH')) exit();?><!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>注册</title>
    <meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">

<?php echo hook('syncMeta');?>

<?php $oneplus_seo_meta = get_seo_meta($vars,$seo); ?>
<?php if($oneplus_seo_meta['title']): ?><title><?php echo ($oneplus_seo_meta['title']); ?></title>
    <?php else: ?>
    <title><?php echo modC('WEB_SITE_NAME',L('_OPEN_SNS_'),'Config');?></title><?php endif; ?>
<?php if($oneplus_seo_meta['keywords']): ?><meta name="keywords" content="<?php echo ($oneplus_seo_meta['keywords']); ?>"/><?php endif; ?>
<?php if($oneplus_seo_meta['description']): ?><meta name="description" content="<?php echo ($oneplus_seo_meta['description']); ?>"/><?php endif; ?>

<link rel="shortcut icon" type="image/x-icon" href="/favicon.ico" media="screen" />

<!-- zui -->
<link href="/Public/zui/css/zui.css" rel="stylesheet">

<link href="/Public/zui/css/zui-theme.css" rel="stylesheet">
<link href="/Public/static/os-icon/simple-line-icons.min.css" rel="stylesheet">
<link href="/Public/static/os-loading/loading.css" rel="stylesheet">
<link href="/Public/css/core.css" rel="stylesheet"/>
<link type="text/css" rel="stylesheet" href="/Public/js/ext/magnific/magnific-popup.css"/>
<link type="text/css" rel="stylesheet" href="//at.alicdn.com/t/font_m3e1llc4usypsyvi.css"/>
<!--<script src="/Public/js/jquery-2.0.3.min.js"></script>
<script type="text/javascript" src="/Public/js/com/com.functions.js"></script>

<script type="text/javascript" src="/Public/js/core.js"></script>-->
<script src="/Public/js.php?f=js/jquery-2.0.3.min.js,js/com/com.functions.js,static/os-loading/loading.js,js/core.js,js/com/com.toast.class.js,js/com/com.ucard.js"></script>



<!--Style-->
<!--合并前的js-->
<?php $config = api('Config/lists'); C($config); $count_code=C('COUNT_CODE'); ?>
<script type="text/javascript">
    var ThinkPHP = window.Think = {
        "ROOT": "", //当前网站地址
        "APP": "/index.php?s=", //当前项目地址
        "PUBLIC": "/Public", //项目公共目录地址
        "DEEP": "<?php echo C('URL_PATHINFO_DEPR');?>", //PATHINFO分割符
        "MODEL": ["<?php echo C('URL_MODEL');?>", "<?php echo C('URL_CASE_INSENSITIVE');?>", "<?php echo C('URL_HTML_SUFFIX');?>"],
        "VAR": ["<?php echo C('VAR_MODULE');?>", "<?php echo C('VAR_CONTROLLER');?>", "<?php echo C('VAR_ACTION');?>"],
        'URL_MODEL': "<?php echo C('URL_MODEL');?>",
        'WEIBO_ID': "<?php echo C('SHARE_WEIBO_ID');?>"
    }
    var cookie_config={
        "prefix":"<?php echo C('COOKIE_PREFIX');?>",// cookie 名称前缀
        "path" :"<?php echo C('COOKIE_PATH');?>", // cookie 保存路径
        "domain":"<?php echo C('COOKIE_DOMAIN');?>" // cookie 有效域名
    }
    var Config={
        'GET_INFORMATION':<?php echo modC('GET_INFORMATION',1,'Config');?>,
        'GET_INFORMATION_INTERNAL':<?php echo modC('GET_INFORMATION_INTERNAL',10,'Config');?>*1000,
        'WEBSOCKET_ADDRESS':"<?php echo modC('WEBSOCKET_ADDRESS',gethostbyname($_SERVER['SERVER_NAME']),'Config');?>",
        'WEBSOCKET_PORT':<?php echo modC('WEBSOCKET_PORT',8000,'Config');?>
    }
    var weibo_comment_order = "<?php echo modC('COMMENT_ORDER',0,'WEIBO');?>";
</script>

<script src="/Public/lang.php?module=<?php echo strtolower(MODULE_NAME);?>&lang=<?php echo LANG_SET;?>"></script>

<script src="/Public/expression.php"></script>

<!-- Bootstrap库 -->
<!--
<?php $js[]=urlencode('/static/bootstrap/js/bootstrap.min.js'); ?>

&lt;!&ndash; 其他库 &ndash;&gt;
<script src="/Public/static/qtip/jquery.qtip.js"></script>
<script type="text/javascript" src="/Public/Core/js/ext/slimscroll/jquery.slimscroll.min.js"></script>
<script type="text/javascript" src="/Public/static/jquery.iframe-transport.js"></script>
-->
<!--CNZZ广告管家，可自行更改-->
<!--<script type='text/javascript' src='http://js.adm.cnzz.net/js/abase.js'></script>-->
<!--CNZZ广告管家，可自行更改end-->
<!-- 自定义js -->
<!--<script src="/Public/js.php?get=<?php echo implode(',',$js);?>"></script>-->

<?php D('Pushing')->doRun(); $key = C('DATA_AUTH_KEY'); $timestamp = time(); $signature = md5(is_login().$timestamp.$key); ?>
<script>
    //全局内容的定义
    var _ROOT_ = "";
    var MID = "<?php echo is_login();?>";
    var SIGNATURE = "<?php echo ($signature); ?>";
    var TIMESTAMP = "<?php echo ($timestamp); ?>";
    var MODULE_NAME="<?php echo MODULE_NAME; ?>";
    var ACTION_NAME="<?php echo ACTION_NAME; ?>";
    var CONTROLLER_NAME ="<?php echo CONTROLLER_NAME; ?>";
    var initNum = "<?php echo modC('WEIBO_NUM',140,'WEIBO');?>";
    function adjust_navbar(){
        $('#sub_nav').css('top',$('#nav_bar').height());
        $('#main-container').css('padding-top',$('#nav_bar').height()+$('#sub_nav').height()+20)
    }
</script>

<audio id="music" src="" autoplay="autoplay"></audio>
<!-- 页面header钩子，一般用于加载插件CSS文件和代码 -->
<?php echo hook('pageHeader');?>
    <link href="/Application/Ucenter/Static/css/center.css" type="text/css" rel="stylesheet">
    <script src="/Application/Ucenter/Static/js/jquery.js"></script>
    <!--<script src="/Application/Ucenter/Static/js/canvas.js"></script>-->
    <!-- jQuery (ZUI中的Javascript组件依赖于jQuery) -->


<!-- 为了让html5shiv生效，请将所有的CSS都添加到此处 -->
<link type="text/css" rel="stylesheet" href="/Public/static/qtip/jquery.qtip.css"/>


<!--<script type="text/javascript" src="/Public/js/com/com.notify.class.js"></script>-->

<!-- 其他库-->
<!--<script src="/Public/static/qtip/jquery.qtip.js"></script>
<script type="text/javascript" src="/Public/js/ext/slimscroll/jquery.slimscroll.min.js"></script>
<script type="text/javascript" src="/Public/static/jquery.iframe-transport.js"></script>

<script type="text/javascript" src="/Public/js/ext/magnific/jquery.magnific-popup.min.js"></script>-->

<!--<script type="text/javascript" src="/Public/js/ext/placeholder/placeholder.js"></script>
<script type="text/javascript" src="/Public/js/ext/atwho/atwho.js"></script>
<script type="text/javascript" src="/Public/zui/js/zui.js"></script>-->
<link type="text/css" rel="stylesheet" href="/Public/js/ext/atwho/atwho.css"/>

<script src="/Public/js.php?t=js&f=js/com/com.notify.class.js,static/qtip/jquery.qtip.js,js/ext/slimscroll/jquery.slimscroll.min.js,js/ext/magnific/jquery.magnific-popup.min.js,js/ext/placeholder/placeholder.js,js/ext/atwho/atwho.js,zui/js/zui.js&v=<?php echo ($site["sys_version"]); ?>.js"></script>
<script type="text/javascript" src="/Public/static/jquery.iframe-transport.js"></script>

<script src="/Public/js/ext/lazyload/lazyload.js"></script>

<script src="/Public/js/socket.io.js"></script>
</head>
<body>

<div class="banner">
    <!--<canvas id="canvas" width="1835" height="950"></canvas>-->

    <div class="logo-box">
        <?php $logo = get_cover(modC('LOGO',0,'Config'),'path'); $logo = $logo?$logo:'/Public/images/logo.png'; ?>
        <a class="navbar-brand logo" href="<?php echo U('Home/Index/index');?>"><img src="<?php echo ($logo); ?>"/></a>
    </div>
</div>
    <div class="login-box">
        <?php if($step == 'start'): ?><div class="col-xs-9 info-box">
                <form action="<?php echo U('register');?>" method="post">
                    <ul id="reg_nav" class="nav nav-tabs" style="margin-bottom: 20px;">
                        <?php if(check_reg_type('email')){ ?>
                        <li <?php if($regSwitch[0] == 'email'): ?>class="active"<?php endif; ?>><a href="#email_reg" data-toggle="tab"><?php echo L('_REGISTER_EMAIL_');?></a></li>
                        <?php } ?>
                        <?php if(check_reg_type('mobile')){ ?>
                        <li <?php if($regSwitch[0] == 'mobile'): ?>class="active"<?php endif; ?>><a href="#mobile_reg" data-toggle="tab"><?php echo L('_REGISTER_PHONE_');?></a></li>
                        <?php } ?>
                    </ul>

                    <div class="tab-content">
                        <?php if(isset($invite_user)){ ?>
                        <div class="alert alert-info"><?php echo L('_USER_');?> <?php echo ($invite_user['nickname']); ?> <?php echo L('_REGISTER_INVITE_'); echo C('WEB_SITE');?>，<?php echo L('_REGISTER_INFORMATION_FILL_OUT_');?>~</div>
                        <input type="hidden" name="code" value="<?php echo ($code); ?>">
                        <?php }else{ ?>
                        <?php if($open_invite_register): ?><div class="alert alert-info" style="margin-top: 0"><?php echo L('_USER_INVITE_FIRST_');?><strong><a data-type="ajax" data-url="<?php echo U('Ucenter/Member/inCode');?>" data-title="<?php echo L('_INVITE_CODE_INPUT_');?>" data-toggle="modal"><?php echo L('_INVITE_CODE_INPUT_');?></a></strong>，<?php echo L('_REGISTER_INFORMATION_FILL_OUT_');?>~</div><?php endif; ?>
                        <?php } ?>
                        <?php if(count($role_list)==1): ?><input id="name" type="hidden" name="role" value="<?php echo ($role_list[0]['id']); ?>">
                            <?php else: ?>
                            <div class="form-group" style="margin: 30px 0">
                                <input id="name" type="hidden" name="role" value="<?php echo ($role_list[0]['id']); ?>">
                                <label for="role" class=".sr-only col-xs-12" style="display: none"></label>
                                <div class="clearfix"></div>
                                <ul id="role-list" class="nav nav-justified nav-pills">
                                    <li class="text-center"><?php echo L('_REGISTER_IDENTITY_SELECT_');?></li>
                                    <?php if(is_array($role_list)): $i = 0; $__LIST__ = $role_list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$role): $mod = ($i % 2 );++$i;?><li><a onclick="$('#name').val(<?php echo ($role["id"]); ?>);$('#role-list li').removeClass('active');$(this).parent().addClass('active');"><i class="icon-user"></i> <?php echo ($role["title"]); ?> </a></li><?php endforeach; endif; else: echo "" ;endif; ?>
                                </ul>
                                <script>
                                    $(function(){
                                        $('#role-list li').eq(1).addClass('active');
                                    })
                                </script>
                                <span class="help-block"></span>
                            </div><?php endif; ?>
                        <?php if(is_array($regSwitch)): $i = 0; $__LIST__ = $regSwitch;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$regSwitch): $mod = ($i % 2 );++$i; switch($regSwitch): case "email": ?><!--邮箱注册-->
                                    <div class="tab-pane <?php if($key == 0): ?>active in<?php endif; ?>" id="email_reg">

                                        <div class="form-group new-form">
                                            <label for="email" class=".sr-only col-xs-12" style="display: none"></label>
                                            <span class="new-icon email-icon"></span>
                                            <input type="text" id="email" class="form-control form_check new-input" check-type="UserEmail" check-url="<?php echo U('ucenter/member/checkAccount');?>" <?php if($key != 0): ?>disabled="disabled"<?php endif; ?>
                                            placeholder="<?php echo L('_PLACEHOLDER_EMAIL_INPUT_');?>" value="" name="username">
                                            <input type="hidden" name="reg_type" value="email" <?php if($key != 0): ?>disabled="disabled"<?php endif; ?>>
                                        </div>
                                        <span class="tips"><?php echo L('_EMAIL_INPUT_');?></span>


                                        <?php if(modC('EMAIL_VERIFY_TYPE', 0, 'USERCONFIG') == 2){ ?>

                                        <div class="form-group new-form">
                                            <span class="new-icon code-icon"></span>
                                            <input type="text" class="form-control input-new" placeholder="输入邮箱验证码" <?php if($key != 0): ?>disabled="disabled"<?php endif; ?> name="reg_verify">
                                            <a class="get-code green-btn" data-role="getVerify"><?php echo L('_EMAIL_VERIFY_');?></a>
                                            <!--<span class="help-block"><?php echo L('_VERIFY_CODE_INPUT_');?></span>-->
                                        </div>

                                        <div class="form-group new-form verify-check" style=" display:none;">
                                            <h3>确认发送验证码</h3>
                                            <div class="row">
                                                <div class="col-xs-6">
                                                    <div class="lg_lf_fm_verify">
                                                        <img class="verifyimg reloadverify img-responsive" alt="点击切换" src="<?php echo U('verify',array('id'=>3));?>">
                                                    </div>
                                                    <div class="col-xs-12 Validform_checktip text-warning lg_lf_fm_tip"></div>
                                                </div>
                                                <div class="col-xs-6 input-box">
                                                    <label for="verifyCode3" class=".sr-only col-xs-12" style="display: none"></label>
                                                    <span class="new-icon code-icon"></span>
                                                    <input type="text" id="verifyCode3" class="form-control" placeholder="图片验证码"
                                                           errormsg="请填写正确的验证码" nullmsg="请填写验证码" datatype="*5-5" name="verify">
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-xs-6">
                                                    <button class="btn y-btn" data-role="checkVerify">确定</button>
                                                </div>
                                                <div class="col-xs-6">
                                                    <button class="btn c-btn" data-role="closeVerify">取消</button>
                                                </div>
                                            </div>
                                    </div>
                                        <?php } else { ?>
                                        <?php if(check_verify_open('reg')): ?><div class="form-group new-form">
                                                <label for="verifyCode4" class=".sr-only col-xs-12"
                                                       style="display: none"></label>
                                                <span class="new-icon code-icon"></span>
                                                <input type="text" id="verifyCode4" class="form-control new-input" placeholder="验证码"
                                                       errormsg="请填写正确的验证码" nullmsg="请填写验证码" datatype="*5-5" name="verify">

                                                <div class="new-code lg_lf_fm_verify">
                                                    <img class="verifyimg reloadverify img-responsive" alt="点击切换"
                                                         src="<?php echo U('verify');?>">
                                                </div>
                                                <div class="col-xs-12 Validform_checktip text-warning lg_lf_fm_tip"></div>
                                                <div class="clearfix"></div>
                                            </div>
                                            <span class="tips">输入验证码</span><?php endif; ?>
                                        <?php } ?>

                                    </div>
                                    <!--邮箱注册end--><?php break;?>
                                <?php case "mobile": ?><!--手机注册-->
                                    <div class="tab-pane <?php if($key == 0): ?>active in<?php endif; ?>" id="mobile_reg">

                                        <div class="form-group new-form">
                                            <label for="mobile" class=".sr-only col-xs-12" style="display: none"></label>
                                            <span class="new-icon phone-icon"></span>
                                            <input type="text" id="mobile" class="form-control form_check new-input" check-type="UserMobile" check-url="<?php echo U('ucenter/member/checkAccount');?>" <?php if($key != 0): ?>disabled="disabled"<?php endif; ?>
                                            placeholder="<?php echo L('_PLACEHOLDER_PHONE_');?>" .
                                            errormsg="<?php echo L('_ERROR_PHONE_INPUT_');?>" value="" name="username">

                                            <input type="hidden" name="reg_type" value="mobile" <?php if($key != 0): ?>disabled="disabled"<?php endif; ?>>
                                        </div>
                                        <span class="tips"><?php echo L('_PHONE_INPUT_');?></span>

                                        <?php if(modC('MOBILE_VERIFY_TYPE', 0, 'USERCONFIG') == 1){ ?>

                                        <div class="form-group new-form">
                                            <span class="new-icon code-icon"></span>
                                            <input type="text" class="form-control new-input" placeholder="<?php echo L('_VERIFY_CODE_');?>" name="reg_verify" <?php if($key != 0): ?>disabled="disabled"<?php endif; ?>>
                                            <a class="get-code green-btn" data-role="getVerify"><?php echo L('_PHONE_VERIFY_');?></a>
                                        </div>
                                        <span class="tips"><?php echo L('_VERIFY_CODE_INPUT_');?></span>

                                        <div class="form-group new-form verify-check" style=" display:none;">
                                            <h3>确认发送验证码</h3>
                                            <div class="row">
                                                <div class="col-xs-6">

                                                    <div class="lg_lf_fm_verify">
                                                        <img class="verifyimg reloadverify img-responsive" alt="点击切换" src="<?php echo U('verify',array('id'=>2));?>">
                                                    </div>
                                                    <div class="col-xs-12 Validform_checktip text-warning lg_lf_fm_tip"></div>
                                                </div>
                                                <div class="col-xs-6 input-box">
                                                    <label for="verifyCode2" class=".sr-only col-xs-12" style="display: none"></label>
                                                    <span class="new-icon code-icon"></span>
                                                    <input type="text" id="verifyCode2" class="form-control" placeholder="图片验证码"
                                                           errormsg="请填写正确的验证码" nullmsg="请填写验证码" datatype="*5-5" name="verify">
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-xs-6">
                                                    <button class="btn y-btn" data-role="checkVerify">确定</button>
                                                </div>
                                                <div class="col-xs-6">
                                                    <button class="btn c-btn" data-role="closeVerify">取消</button>
                                                </div>
                                            </div>
                                        </div>
                                        <?php } else { ?>
                                        <?php if(check_verify_open('reg')): ?><div class="form-group new-form">
                                                <label for="verifyCode5" class=".sr-only col-xs-12"
                                                       style="display: none"></label>
                                                <span class="new-icon code-icon"></span>
                                                <input type="text" id="verifyCode5" class="form-control new-input" placeholder="验证码"
                                                       errormsg="请填写正确的验证码" nullmsg="请填写验证码" datatype="*5-5" name="verify">

                                                <div class="new-code lg_lf_fm_verify">
                                                    <img class="verifyimg reloadverify img-responsive" alt="点击切换"
                                                         src="<?php echo U('verify');?>">
                                                </div>
                                                <div class="col-xs-12 Validform_checktip text-warning lg_lf_fm_tip"></div>
                                                <div class="clearfix"></div>
                                            </div>
                                            <span class="tips">输入验证码</span><?php endif; ?>
                                        <?php } ?>

                                    </div>
                                    <!--手机注册end--><?php break; endswitch; endforeach; endif; else: echo "" ;endif; ?>



                        <div class="form-group new-form">
                            <label for="nickname" class=".sr-only col-xs-12" style="display: none"></label>
                            <span class="new-icon name-icon"></span>
                            <input type="text" id="nickname" class="form-control form_check new-input" check-type="Nickname"  check-url="<?php echo U('ucenter/member/checkNickname');?>" placeholder="请输入昵称" value="" name="nickname">
                        </div>
                        <span class="tips">输入昵称，只允许中文、字母和数字和下划线</span>
                        <div class="form-group new-form password_block">
                            <input name="code" id="code" value="<?php echo ($code); ?>" type="hidden">
                            <span class="new-icon password-icon"></span>
                            <input type="password" id="inputPassword" class="form-control new-input" check-length="6,30"  placeholder="请输入密码"  name="password">

                            <div class="input-group-addon show-password green-btn">
                                <a  href="javascript:void(0);" onclick="change_show(this)">show</a>
                            </div>

                        </div>
                        <span class="tips">请输入密码，6-30位字符</span>

                        <!--<div style="float: left;vertical-align: bottom;margin-top: 12px;color: #848484;">
                            已有账户， <a href="<?php echo U('Ucenter/Member/login');?>" title="" style="color: #03B38B;">登录</a>
                        </div>-->
                        <button type="submit" class="btn btn-primary new-btn green-btn">注册</button>


                    </div>
                </form>
            </div>
            <div class="col-xs-3 right-box">
                <p class="p1">已有账号？</p>
                <a href="<?php echo U('Ucenter/Member/login');?>"><p class="p2">直接登录</p></a>
                <p class="p3">使用以下账号直接登录</p>
                <p class="i-group">
                    <?php echo hook('syncLogin');?>
                </p>
            </div><?php endif; ?>
        <?php if($step != 'start' and $step != 'finish'): echo W('RegStep/view'); endif; ?>
        <?php if($step == 'finish'): ?><div class="col-xs-12" style="font-size: 16px;margin-top: 30px;">
                    <span>感谢您注册 <?php echo modC('WEB_SITE_NAME','OpenSNS开源社交系统','Config');?> ，希望你玩的愉快！
                        <a class="btn y-btn" href="<?php echo U('Ucenter/Config/index');?>" title="">完善个人资料</a> 或
                        <a class="btn y-btn" href="<?php echo U('home/Index/index');?>" title="">前往首页</a></span>
            </div><?php endif; ?>

    </div>
<div class="foot">
    <h4>— 专注社交，从未止步 —</h4>
</div>





    <script>
        $(function(){
            $('.new-input').focus(function () {
                $(this).closest(".new-form").css('marginBottom','15px').next().css('display','block');
            });
            $('.new-input').blur(function () {
                $(this).closest(".new-form").css('marginBottom','30px').next().css('display','none');
            })
        })
    </script>
    <script type="text/javascript">
        var step="<?php echo ($step); ?>";
        if (MID == 0&&step=='start') {
            $(document)
                    .ajaxStart(function () {
                        $("button:submit").addClass("log-in").attr("disabled", true);
                    })
                    .ajaxStop(function () {
                        $("button:submit").removeClass("log-in").attr("disabled", false);
                    });
            $("form").submit(function () {
                toast.showLoading();
                var self = $(this);
//                console.log(self.serialize());
                $.post(self.attr("action"), self.serialize(), success, "json");
                return false;

                function success(data) {
                    if (data.status) {
                        //toast.success(data.info, '温馨提示');
                        setTimeout(function () {
                            window.location.href = data.url
                        }, 10);
                    } else {
                        toast.error(data.info, '温馨提示');
                        //self.find(".Validform_checktip").text(data.info);
                        //刷新验证码
                        $(".reloadverify").click();
                    }
                    toast.hideLoading();
                }
            });

            function change_show(obj) {
                if ($(obj).text().trim() == 'show') {
                    $(obj).html('hide');
                    $(obj).parents('.password_block').find('input').attr('type', 'text');
                } else {
                    $(obj).html('show');
                    $(obj).parents('.password_block').find('input').attr('type', 'password');
                }
                $('#code').attr('type','hidden');
            }


            function setNickname(obj) {
                var text = jQuery.trim($(obj).val());
                if (text != null && text != '') {
                    $('#nickname').val(text);
                }
            }

            $(function () {

                $(".reloadverify").click(function () {
                    var $this = $(this);
                    var verifyimg = $this.attr("src");
                    $this.attr("src", verifyimg + '&random=' + Math.random());
                });
            });



            $(function () {
                $("[data-role='getVerify']").click(function () {
                    var $this = $(this);
//                    toast.showLoading();
                    var account = $this.parents('.tab-pane').find('[name="username"]').val();
                    var type = $this.parents('.tab-pane').find('[name="reg_type"]').val();
//                    var url = "<?php echo U('ucenter/member/checkAccount');?>";

                    $.post(U('ucenter/member/checkAccount'),{account:account,type:type},function(res){
                        ajaxRerurn(res);
                        if(res.info == '验证成功') {
                            $('.verify-check').show();
                            $('[data-role="closeVerify"]').click(function() {
                                $('.verify-check').hide();
                                return false;
                            })
                        }
                    },'json')
                });

                $('[data-role="checkVerify"]').click(function(event) {
                    var $this = $(this);
//                    toast.showLoading();
                    var account = $this.parents('.tab-pane').find('[name="username"]').val();
                    var type = $this.parents('.tab-pane').find('[name="reg_type"]').val();
                    var verify = $this.parents('.tab-pane').find('[name="verify"]').val();

                    $.post("<?php echo U('ucenter/verify/sendVerify');?>", {account: account, type: type, action: 'member',verify:verify,type_other:1}, function (res) {
                        if (res.status) {
                            $('.verify-check').hide();
                            DecTime.obj = $this;
                            DecTime.time = "<?php echo modC('SMS_RESEND','60','USERCONFIG');?>";
                            $this.attr('disabled',true);
                            DecTime.dec_time();

                            toast.success(res.info);
                        }
                        else {
                            toast.error(res.info);
                        }
                        toast.hideLoading();
                    });
                    event.preventDefault();
                });

                $('#reg_nav li a').click(function(){
                    $('.tab-pane').find('input').attr('disabled',true);
                    $('.tab-pane').eq($("#reg_nav li a").index(this)).find('input').attr('disabled',false);
                })
                $("[type='submit']").click(function () {
                    $(this).parents('form').submit();
                })

                $('[href="#<?php echo ($type); ?>_reg"]').click()


            })
        }



        var DecTime = {
            obj:0,
            time:0,
            dec_time : function(){
                if(this.time > 0){
                    this.obj.text(this.time--+'S')
                    setTimeout("DecTime.dec_time()",1000)
                }else{
                    this.obj.text("<?php echo L('_EMAIL_VERIFY_');?>")
                    this.obj.attr('disabled',false)
                }

            }
        }

    </script>
    <link href="/Application/Core/Static/css/form_check.css" rel="stylesheet" type="text/css">
    <script src='/Application/Core/Static/js/form_check.js'></script>
    <script>
        // 验证密码长度
        $(function(){
            $('#inputPassword').after('<div class=" show_info" ></div>');
            $('#inputPassword').blur(function(){

                var obj =$('#inputPassword');
                var str =  obj.val().replace(/s+/g, "");
                var html = '';
                if (str.length == 0) {
                    html = '<div class="send red"><div class="arrow"></div>'+"<?php echo L('_EMPTY_CANNOT_');?>"+'</div>';
                } else {
                    if (typeof (obj.attr('check-length')) != 'undefined') {
                        var strs = new Array(); //定义一数组
                        strs = obj.attr('check-length').split(","); //字符分割
                        if (strs[1]) {
                            if (strs[1] < str.length || str.length < strs[0]) {
                                html = '<div class="send red"><div class="arrow"></div>'+"<?php echo L('_LENGTH_ILLEGAL_');?>"+'</div>';
                            }
                        }
                        else {
                            if (strs[0] < str.length) {
                                html = '<div class="send red"><div class="arrow"></div>'+"<?php echo L('_LENGTH_ILLEGAL_');?>"+'</div>';
                            }
                        }
                    }
                    obj.parent().find('.show_info').html(html);
                }
            })
        })
    </script>

</body>
</html>