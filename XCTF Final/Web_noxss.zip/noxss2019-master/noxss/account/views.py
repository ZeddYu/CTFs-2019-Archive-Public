from django.shortcuts import render, redirect, HttpResponse

from django.contrib.auth import authenticate, login
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.decorators import login_required

from .models import Profile


def registerView(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            raw_password = form.cleaned_data.get('password1')
            user = authenticate(username=username, password=raw_password)
            login(request, user)
            return redirect('account:userinfo')
    else:
        form = UserCreationForm()
    return render(request, 'account/register.html', {'form': form})


@login_required
def userinfoView(request):
    theme = request.GET.get('theme', '')
    if theme:
        request.user.profile.theme = theme
        request.user.profile.save()

    return render(request, 'account/userinfo.html', context={'skin_list': ['cerulean', 'cyborg', 'default', 'journal', 'lumen', 'materia', 'pulse', 'simplex', 'slate', 'spacelab', 'united', 'cosmo', 'darkly', 'flatly', 'litera', 'lux', 'minty', 'sandstone', 'sketchy', 'solar', 'superhero', 'yeti']})


@login_required
def setStatus(request):
    if request.method == 'POST':
        status = request.POST.get('status', '')
        if len(status) <= 100:
            request.user.profile.status = status
            request.user.profile.save()
            print(request.user.profile.status)
            return HttpResponse(status=200)
    return HttpResponse(status=400)
