from django.urls import path, re_path
from django.contrib.auth.views import LoginView, LogoutView
from .views import *

app_name='account'
urlpatterns = [
	path('login', LoginView.as_view(template_name='account/login.html'), name='login'),
	path('register', registerView, name='register'),
	path('logout', LogoutView.as_view(next_page='site-root'), name='logout'),

	path('userinfo', userinfoView, name='userinfo'),
	path('setstatus', setStatus),
]
