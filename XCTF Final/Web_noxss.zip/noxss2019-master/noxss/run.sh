pip install -r requirements.txt
cp db.sqlite3.bak db.sqlite3
head -c 64 /dev/urandom > secret.key
python manage.py shell -c "from bot_config import bot; from django.contrib.auth.models import User; User.objects.create_user(is_staff=True, **bot).save()"
gunicorn -c gunicorn_config.py noxss.wsgi
